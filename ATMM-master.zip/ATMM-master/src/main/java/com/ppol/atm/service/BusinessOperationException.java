package com.ppol.atm.service;

public class BusinessOperationException extends Exception {

    public BusinessOperationException(final String message) {
        super(message);
    }
}
