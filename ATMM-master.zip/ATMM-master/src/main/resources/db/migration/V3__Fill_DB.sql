INSERT INTO cards (id, card_num, balance, blocked, pin) VALUES (1,1111111111111111,50.22,0,1111);
INSERT INTO cards (id, card_num, balance, blocked, pin) VALUES (2,1111111111111112,751.22,1,2222);
INSERT INTO cards (id, card_num, balance, blocked, pin) VALUES (3,1111111111111113,0,0,3333);
INSERT INTO cards (id, card_num, balance, blocked, pin) VALUES (4,1111111111111114,0,1,4444);